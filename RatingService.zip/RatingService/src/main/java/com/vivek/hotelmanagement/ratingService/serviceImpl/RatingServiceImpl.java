package com.vivek.hotelmanagement.ratingService.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.vivek.hotelmanagement.ratingService.dto.RatingDto;
import com.vivek.hotelmanagement.ratingService.entity.Rating;
import com.vivek.hotelmanagement.ratingService.repository.RatingRepository;
import com.vivek.hotelmanagement.ratingService.service.RatingService;

public class RatingServiceImpl implements RatingService{
	
	@Autowired(required = true)
	private RatingRepository ratingRepository;

	@Override
	public Rating create(RatingDto ratingDto) {
		
		Rating rating=new Rating();
		rating.setHotelId(ratingDto.getHotelId());
		rating.setUserId(ratingDto.getUserId());
		rating.setRating(ratingDto.getRating());
		rating.setFeedback(ratingDto.getFeedback());

		return ratingRepository.save(rating);
	}

	@Override
	public List<Rating> getAllRating() {
		
		return ratingRepository.findAll();
	}

	@Override
	public List<Rating> getAllRatingByUserId(Long userId) {
		
		return ratingRepository.findByUserId(userId);
	}

	@Override
	public List<Rating> getAllRatingByHotelId(Long hotelId) {
		
		return ratingRepository.findByHotelId(hotelId);
	}

}
