package com.vivek.hotelmanagement.ratingService.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.vivek.hotelmanagement.ratingService.dto.RatingDto;
import com.vivek.hotelmanagement.ratingService.dto.RatingListResponse;
import com.vivek.hotelmanagement.ratingService.dto.RatingResponseDto;
import com.vivek.hotelmanagement.ratingService.entity.Rating;
import com.vivek.hotelmanagement.ratingService.service.RatingService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/rating")
public class RatingController {
	
	@Autowired(required = true)
	private  RatingService ratingService;
	
	@PostMapping("/create")
	public ResponseEntity<RatingResponseDto> create(@RequestBody @Valid RatingDto ratingDto) {
		
		Rating rating=ratingService.create(ratingDto);
		RatingResponseDto ratingResponseDto=new RatingResponseDto(
				rating.getId(),
				rating.getUserId(),
				rating.getHotelId(),
				rating.getRating(),
				rating.getFeedback(),
	    		"your rating successfully added."
	    		);
	    
	    return ResponseEntity.status(HttpStatus.CREATED).body(ratingResponseDto);
	}
	
	@GetMapping("/all")
	public ResponseEntity<RatingListResponse> findAllRating() {
		
		List<Rating> list=ratingService.getAllRating();
		
		RatingListResponse ratingResponseDto=new RatingListResponse();
		ratingResponseDto.setList(list);
			
	    return ResponseEntity.status(HttpStatus.OK).body(ratingResponseDto);
	}
	
	@GetMapping("/{userId}")
	public ResponseEntity<RatingListResponse> findAllRatingByUser(@PathVariable Long userId) {
		
		List<Rating> list=ratingService.getAllRatingByUserId(userId);
		
		RatingListResponse ratingResponseDto=new RatingListResponse();
		ratingResponseDto.setList(list);
			
	    return ResponseEntity.status(HttpStatus.OK).body(ratingResponseDto);
	}
	
	@GetMapping("/{hotelId}")
	public ResponseEntity<RatingListResponse> findAllRatingByHotel(@PathVariable Long hotelId) {
		
		List<Rating> list=ratingService.getAllRatingByHotelId(hotelId);
		
		RatingListResponse ratingResponseDto=new RatingListResponse();
		ratingResponseDto.setList(list);
			
	    return ResponseEntity.status(HttpStatus.OK).body(ratingResponseDto);
	}
	

}
