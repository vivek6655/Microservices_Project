package com.vivek.hotelmanagement.ratingService.dto;

public class RatingDto {
	
	private Long userId;
    private Long hotelId;
    private int rating;
    private String feedback;
    
	public RatingDto(Long userId, Long hotelId, int rating, String feedback) {
		super();
		this.userId = userId;
		this.hotelId = hotelId;
		this.rating = rating;
		this.feedback = feedback;
	}
	
	public RatingDto() {
		super();
	}
	
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public Long getHotelId() {
		return hotelId;
	}
	public void setHotelId(Long hotelId) {
		this.hotelId = hotelId;
	}
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	public String getFeedback() {
		return feedback;
	}
	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}
    
}
