package com.vivek.hotelmanagement.ratingService.dto;

import java.util.List;

import com.vivek.hotelmanagement.ratingService.entity.Rating;

public class RatingListResponse {
	
	List<Rating> list;

	public List<Rating> getList() {
		return list;
	}

	public void setList(List<Rating> list) {
		this.list = list;
	}

	
	
	

}
