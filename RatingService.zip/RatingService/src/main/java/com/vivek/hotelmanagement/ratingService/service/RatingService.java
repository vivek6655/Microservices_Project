package com.vivek.hotelmanagement.ratingService.service;

import java.util.List;

import com.vivek.hotelmanagement.ratingService.dto.RatingDto;
import com.vivek.hotelmanagement.ratingService.entity.Rating;

public interface RatingService {
	
	Rating create(RatingDto ratingDto);
	
	List<Rating> getAllRating();
	
	List<Rating> getAllRatingByUserId(Long userId);
	
	List<Rating> getAllRatingByHotelId(Long hotelId);

}
