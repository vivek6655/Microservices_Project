package com.vivek.hotelmanagement.hotelapp.service;

import java.util.List;
import java.util.Map;

import com.vivek.hotelmanagement.hotelapp.dto.CustomerDto;
import com.vivek.hotelmanagement.hotelapp.entity.Customer;

public interface CustomerService {
	
	public Customer create(CustomerDto customerDto);
	
	public List<Customer> getAllCustomer();
	
	public Customer getCustomer(Long id);
	
	public Customer updateCustomer(Long id,CustomerDto customerDto);
	
	public Customer deleteCustomer(Long id);
	
	public Customer patchCustomerUpdate(Long id,Map<String, Object> updates);
	
}
