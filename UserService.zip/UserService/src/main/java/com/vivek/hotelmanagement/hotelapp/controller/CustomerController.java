package com.vivek.hotelmanagement.hotelapp.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.vivek.hotelmanagement.hotelapp.dto.AbstractResponseDto;
import com.vivek.hotelmanagement.hotelapp.dto.CustomerDto;
import com.vivek.hotelmanagement.hotelapp.dto.CustomerListResponse;
import com.vivek.hotelmanagement.hotelapp.dto.CustomerResponseDto;
import com.vivek.hotelmanagement.hotelapp.entity.Customer;
import com.vivek.hotelmanagement.hotelapp.service.CustomerService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/users")
public class CustomerController {
	
	@Autowired(required = true)
	private CustomerService customerService;
	
	@PatchMapping("patch/{id}")
	public ResponseEntity<CustomerResponseDto> patchUser(
	        @PathVariable Long id,
	        @RequestBody Map<String, Object> updates) {
		
	    Customer customer = customerService.patchCustomerUpdate(id, updates);
	    
	    CustomerResponseDto customerResponseDto=new CustomerResponseDto(
	    		customer.getId(),
	    		customer.getName(),
	    		customer.getEmail(),
	    		customer.getAbout(),
	    		"Customer details have been successfully updated."
	    		);
	    
	    return ResponseEntity.ok(customerResponseDto);  
	}
	
	
	@GetMapping("/{id}")
	public ResponseEntity<AbstractResponseDto> getCustomer(@PathVariable Long id) {
		
		
	    Customer customer = customerService.getCustomer(id);

	    AbstractResponseDto customerRes = new AbstractResponseDto();
	    customerRes.setId(customer.getId());
	    customerRes.setName(customer.getName());
	    customerRes.setEmail(customer.getEmail());
	    customerRes.setAbout(customer.getAbout());

	    return ResponseEntity.ok(customerRes);
	}
	
	@PostMapping("/create/customer")
	public ResponseEntity<CustomerResponseDto> create(@RequestBody @Valid CustomerDto customerDto) {
		
		Customer customer=customerService.create(customerDto);
	    CustomerResponseDto customerResponseDto=new CustomerResponseDto(
	    		customer.getId(),
	    		customer.getName(),
	    		customer.getEmail(),
	    		customer.getAbout(),
	    		"Customer details have been successfully created."
	    		);
	    
	    return ResponseEntity.ok(customerResponseDto);  
	}
	

	@GetMapping("/findAll")
	public ResponseEntity<CustomerListResponse> getCustomer() {
		
		List<Customer> customers=customerService.getAllCustomer();
		
		 List<AbstractResponseDto> customerDtos = customers.stream()
		            .map(this::mapToDto)
		            .toList();
		 
		CustomerListResponse customerListResponse=new CustomerListResponse();
		customerListResponse.setList(customerDtos);
		return ResponseEntity.ok(customerListResponse);  
	}
	
	private AbstractResponseDto mapToDto(Customer customer) {
	    AbstractResponseDto dto = new AbstractResponseDto();
	    dto.setId(customer.getId());
	    dto.setName(customer.getName());
	    dto.setEmail(customer.getEmail());
	    dto.setAbout(customer.getAbout());
	    return dto;
	}
		
	@GetMapping("/delete/{id}")
	public ResponseEntity<CustomerResponseDto> deleteCustomer(@PathVariable Long id) {
		
		
		Customer customer=customerService.deleteCustomer(id);
	    CustomerResponseDto customerResponseDto=new CustomerResponseDto(
	    		customer.getId(),
	    		customer.getName(),
	    		customer.getEmail(),
	    		customer.getAbout(),
	    		"Customer details have been successfully deleted."
	    		);
	    
	    return ResponseEntity.ok(customerResponseDto);  
		
		
	}
		
		
}
