package com.vivek.hotelmanagement.hotelapp.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public class CustomerDto {
	
	    @NotBlank(message = "Name is required")          // cannot be null or empty
	    @Size(min = 3, max = 50, message = "Name must be between 3 and 50 characters")
	    private String name;

	    @NotBlank(message = "Email is required")        // cannot be null or empty
	    @Email(message = "Email should be valid")       // must be a valid email format
	    @Size(max = 50, message = "Email must be less than 100 characters")
	    private String email;

	    @Size(max = 100, message = "About must be less than 100 characters")  // optional field with max length
	    private String about;
    

	public CustomerDto(String name, String email, String about) {
		super();
		this.name = name;
		this.email = email;
		this.about = about;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAbout() {
		return about;
	}

	public void setAbout(String about) {
		this.about = about;
	}
    
    
    

}
