package com.vivek.hotelmanagement.hotelapp.serviceImpl;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.aspectj.util.LangUtil.ProcessController.Thrown;
import org.springframework.beans.factory.annotation.Autowired;

import com.vivek.hotelmanagement.hotelapp.dto.CustomerDto;
import com.vivek.hotelmanagement.hotelapp.entity.Customer;
import com.vivek.hotelmanagement.hotelapp.exception.CustomerNotFoundException;
import com.vivek.hotelmanagement.hotelapp.repository.CustomerRepository;
import com.vivek.hotelmanagement.hotelapp.service.CustomerService;

public class CustomerServiceImpl implements CustomerService{
	
	@Autowired(required = true)
	private CustomerRepository customerRepository;

	@Override
	public Customer create(CustomerDto customerDto) {
		
		Customer customer =new Customer();
		
		customer.setName(customerDto.getName());
		customer.setEmail(customerDto.getEmail());
		customer.setAbout(customerDto.getAbout());
		
		return customerRepository.save(customer);
	}

	@Override
	public List<Customer> getAllCustomer() {
		return customerRepository.findAll();
	}

	@Override
	public Customer getCustomer(Long id) {
		Optional<Customer> customerOpt =customerRepository.findById(id);
		
		if (customerOpt.isPresent()) {
	        return customerOpt.get();
	    } else {
	        throw new CustomerNotFoundException("Customer", "id", id);
	    }
		
	}
	 
	 
	@Override
	public Customer updateCustomer(Long id, CustomerDto customerDto) {
		return null;
	}

	@Override
	public Customer deleteCustomer(Long id) {

		Customer customer = customerRepository.findById(id)
	            .orElseThrow(() -> new CustomerNotFoundException("Customer", "id", id));
		
		customerRepository.delete(customer);
		return customer;

	}

	@Override
	public Customer patchCustomerUpdate(Long id, Map<String, Object> updates) {
		
		Customer customer = customerRepository.findById(id)
	            .orElseThrow(() -> new CustomerNotFoundException("Customer", "id", id));

		 // 2. Update fields if present in the map
	    if (updates.containsKey("name")) {
	        customer.setName((String) updates.get("name"));
	    }
	    if (updates.containsKey("email")) {
	        customer.setEmail((String) updates.get("email"));
	    }
	    if (updates.containsKey("about")) {
	        customer.setAbout((String) updates.get("about"));
	    }

	    // 3. Save the updated customer
	    Customer updatedCustomer = customerRepository.save(customer);
	    
		return updatedCustomer;
	}
	
	

}
