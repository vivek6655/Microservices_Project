package com.vivek.hotelmanagement.hotelapp.entity;

import java.io.Serializable;
import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "hotels")
public class Customer implements Serializable{
	
	private static final long serialVersionUID = 1L;

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="USER_ID" , length = 10) 
    private Long id;

	@Column(name = "NAME", length = 50, nullable = false)
	private String name;
	
	@Column(name = "EMAIL", columnDefinition = "VARCHAR(100) NOT NULL" ,unique = true)
    private String email;
	
	@Column(name="ABOUT" , length = 50) 
    private String about;
    
	public Customer() {
		super();
	}

	public Customer(String name, String email, String about) {
		super();
		this.name = name;
		this.email = email;
		this.about = about;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAbout() {
		return about;
	}

	public void setAbout(String about) {
		this.about = about;
	}

	@Override
	public String toString() {
		return "Customer [id=" + id + ", name=" + name + ", email=" + email + ", about=" + about + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(about, email, id, name);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Customer other = (Customer) obj;
		return Objects.equals(about, other.about) && Objects.equals(email, other.email) && Objects.equals(id, other.id)
				&& Objects.equals(name, other.name);
	}
    
    
    

}
