package com.vivek.hotelmanagement.hotelapp.exception;

public class CustomerNotFoundException extends RuntimeException{
	
	 private static final long serialVersionUID = 1L;

	    public CustomerNotFoundException(String resourceName, String fieldName, Object fieldValue) {
	        super(String.format("%s not found with %s : '%s'", resourceName, fieldName, fieldValue));
	    }

	    public CustomerNotFoundException(String message) {
	        super(message);
	    }

}
