package com.vivek.hotelmanagement.hotelapp.dto;

public class CustomerResponseDto extends AbstractResponseDto{
	
	private String message;

	public CustomerResponseDto() {}

    public CustomerResponseDto(Long id, String name, String email, String about, String message) {
        super(id, name, email, about);
        this.message = message;
    }

    // Getter and Setter
    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }
	
	

}
