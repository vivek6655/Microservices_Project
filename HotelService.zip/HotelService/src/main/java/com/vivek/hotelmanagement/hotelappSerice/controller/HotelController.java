package com.vivek.hotelmanagement.hotelappSerice.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.vivek.hotelmanagement.hotelappSerice.dto.AbstractResponseDto;
import com.vivek.hotelmanagement.hotelappSerice.dto.HotelDto;
import com.vivek.hotelmanagement.hotelappSerice.dto.HotelListResponse;
import com.vivek.hotelmanagement.hotelappSerice.dto.HotelResponseDto;
import com.vivek.hotelmanagement.hotelappSerice.entity.Hotel;
import com.vivek.hotelmanagement.hotelappSerice.service.HotelService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/hotel")
public class HotelController {
	
	@Autowired(required = true)
	private HotelService hotelService;

	@PatchMapping("patch/{id}")
	public ResponseEntity<HotelResponseDto> patchUser(
	        @PathVariable Long id,
	        @RequestBody Map<String, Object> updates) {
		
	    Hotel hotel = hotelService.patchHotelUpdate(id, updates);
	    
	    HotelResponseDto customerResponseDto=new HotelResponseDto(
	    		hotel.getId(),
	    		hotel.getName(),
	    		hotel.getLocation(),
	    		hotel.getAbout(),
	    		"Hotel details have been successfully updated."
	    		);
	    
	    return ResponseEntity.ok(customerResponseDto);  
	}
	
	
	@GetMapping("/{id}")
	public ResponseEntity<AbstractResponseDto> getCustomer(@PathVariable Long id) {
		
		
	    Hotel customer = hotelService.getHotel(id);

	    AbstractResponseDto customerRes = new AbstractResponseDto();
	    customerRes.setId(customer.getId());
	    customerRes.setName(customer.getName());
	    customerRes.setLocation(customer.getLocation());
	    customerRes.setAbout(customer.getAbout());

	    return ResponseEntity.ok(customerRes);
	}
	
	@PostMapping("/create/hotel")
	public ResponseEntity<HotelResponseDto> create(@RequestBody @Valid HotelDto customerDto) {
		
		Hotel customer=hotelService.createHotel(customerDto);
	    HotelResponseDto customerResponseDto=new HotelResponseDto(
	    		customer.getId(),
	    		customer.getName(),
	    		customer.getLocation(),
	    		customer.getAbout(),
	    		"hotel details have been successfully created."
	    		);
	    
	    return ResponseEntity.status(HttpStatus.CREATED).body(customerResponseDto);
	}
	

	@GetMapping("/all")
	public ResponseEntity<HotelListResponse> getCustomer() {
		
		List<Hotel> customers=hotelService.getAllHotel();
		
		 List<AbstractResponseDto> customerDtos = customers.stream()
		            .map(this::mapToDto)
		            .toList();
		 
		 HotelListResponse customerListResponse=new HotelListResponse();
		customerListResponse.setList(customerDtos);
		return ResponseEntity.ok(customerListResponse);  
	}
	
	private AbstractResponseDto mapToDto(Hotel customer) {
	    AbstractResponseDto dto = new AbstractResponseDto();
	    dto.setId(customer.getId());
	    dto.setName(customer.getName());
	    dto.setLocation(customer.getLocation());
	    dto.setAbout(customer.getAbout());
	    return dto;
	}
		
	@GetMapping("/delete/{id}")
	public ResponseEntity<HotelResponseDto> deleteCustomer(@PathVariable Long id) {
		
		
		Hotel customer=hotelService.deleteHotel(id);
	    HotelResponseDto customerResponseDto=new HotelResponseDto(
	    		customer.getId(),
	    		customer.getName(),
	    		customer.getLocation(),
	    		customer.getAbout(),
	    		"hotel details have been successfully deleted."
	    		);
	    
	    return ResponseEntity.ok(customerResponseDto);  
		
		
	}
		
}
