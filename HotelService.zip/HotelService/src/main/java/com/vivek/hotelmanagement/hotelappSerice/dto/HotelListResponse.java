package com.vivek.hotelmanagement.hotelappSerice.dto;

import java.util.List;

public class HotelListResponse {
	
	private List<AbstractResponseDto> list;

	public List<AbstractResponseDto> getList() {
		return list;
	}

	public void setList(List<AbstractResponseDto> list) {
		this.list = list;
	}
	
	

}
