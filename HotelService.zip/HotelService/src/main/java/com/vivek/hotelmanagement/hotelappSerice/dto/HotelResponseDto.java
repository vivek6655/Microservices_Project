package com.vivek.hotelmanagement.hotelappSerice.dto;

public class HotelResponseDto extends AbstractResponseDto{
	
	private String message;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	

	public HotelResponseDto() {}

    public HotelResponseDto(Long id, String name, String location, String about, String message) {
        super(id, name, location, about);
        this.message = message;
    }

}
