package com.vivek.hotelmanagement.hotelappSerice.exception;

public class HotelNotFoundException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	
	  public HotelNotFoundException(String resourceName, String fieldName, Object fieldValue) {
	        super(String.format("%s not found with %s : '%s'", resourceName, fieldName, fieldValue));
	    }

	    public HotelNotFoundException(String message) {
	        super(message);
	    }

}
