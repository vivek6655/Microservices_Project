package com.vivek.hotelmanagement.hotelappSerice.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.vivek.hotelmanagement.hotelappSerice.entity.Hotel;

public interface HotelRepository extends JpaRepository<Hotel, Long>{

}
