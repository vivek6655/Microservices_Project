package com.vivek.hotelmanagement.hotelappSerice.service;

import java.util.List;
import java.util.Map;

import com.vivek.hotelmanagement.hotelappSerice.dto.HotelDto;
import com.vivek.hotelmanagement.hotelappSerice.entity.Hotel;

public interface HotelService {
	
    public Hotel createHotel(HotelDto hotelDto);
	
	public List<Hotel> getAllHotel();
	
	public Hotel getHotel(Long id);
	
	public Hotel updateHotel(Long id,HotelDto hotelDto);
	
	public Hotel deleteHotel(Long id);
	
	public Hotel patchHotelUpdate(Long id,Map<String, Object> updates);

}
