package com.vivek.hotelmanagement.hotelappSerice.serviceImpl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vivek.hotelmanagement.hotelappSerice.dto.HotelDto;
import com.vivek.hotelmanagement.hotelappSerice.entity.Hotel;
import com.vivek.hotelmanagement.hotelappSerice.exception.HotelNotFoundException;
import com.vivek.hotelmanagement.hotelappSerice.repository.HotelRepository;
import com.vivek.hotelmanagement.hotelappSerice.service.HotelService;

@Service
public class HotelServiceImpl implements HotelService{
	
	@Autowired(required = true)
	private HotelRepository hotelRepository;

	@Override
	public Hotel createHotel(HotelDto hotelDto) {
		
		Hotel hotel=new Hotel();
		hotel.setName(hotelDto.getName());
		hotel.setLocation(hotelDto.getLocation());
		hotel.setAbout(hotelDto.getAbout());
	
		 return hotelRepository.save(hotel);
	}

	@Override
	public List<Hotel> getAllHotel() {
	
		return hotelRepository.findAll();
	}

	@Override
	public Hotel getHotel(Long id) {
		
		return hotelRepository.findById(id).
				orElseThrow(()-> new HotelNotFoundException("Hotel", "id", id));
	}

	@Override
	public Hotel updateHotel(Long id, HotelDto hotelDto) {
	
		Hotel hotel=hotelRepository.findById(id).
		orElseThrow(()-> new HotelNotFoundException("Hotel", "id", id));
		
		hotel.setName(hotelDto.getName());
		hotel.setLocation(hotelDto.getLocation());
		hotel.setAbout(hotelDto.getAbout());
		
		return hotelRepository.save(hotel);
	}

	@Override
	public Hotel deleteHotel(Long id) {
	
		Hotel hotel=hotelRepository.findById(id).
				orElseThrow(()-> new HotelNotFoundException("Hotel", "id", id));
		hotelRepository.delete(hotel);
		return hotel;
	}

	@Override
	public Hotel patchHotelUpdate(Long id, Map<String, Object> updates) {
		
		Hotel hotel=hotelRepository.findById(id).
				orElseThrow(()-> new HotelNotFoundException("Hotel", "id", id));
		
		 // 2. Update fields if present in the map
	    if (updates.containsKey("name")) {
	    	hotel.setName((String) updates.get("name"));
	    }
	    if (updates.containsKey("location")) {
	    	hotel.setLocation((String)updates.get("location"));
	    }
	    if (updates.containsKey("about")) {
	    	hotel.setAbout((String) updates.get("about"));
	    }

	    // 3. Save the updated customer
	    Hotel updatedHotel = hotelRepository.save(hotel);
	    
		return updatedHotel;
		
	}

}
