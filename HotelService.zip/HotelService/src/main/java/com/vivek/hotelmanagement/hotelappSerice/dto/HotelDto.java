package com.vivek.hotelmanagement.hotelappSerice.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public class HotelDto {
	
	  @NotBlank(message = "Name is required")          // cannot be null or empty
	  @Size(min = 3, max = 50, message = "Name must be between 3 and 50 characters")
      private String name;
	
	  @NotBlank(message = "location is required") 
    private String location;
	
    private String about;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getAbout() {
		return about;
	}

	public void setAbout(String about) {
		this.about = about;
	}

	public HotelDto(String name, String location, String about) {
		super();
		this.name = name;
		this.location = location;
		this.about = about;
	}

	public HotelDto() {
		super();
	}
    
    

}
